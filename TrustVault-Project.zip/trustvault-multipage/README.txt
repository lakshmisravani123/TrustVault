TRUSTVAULT MULTI-PAGE FRONTEND

Pages:
- index.html      Landing / home page
- signin.html     Sign-in page with password visibility and demo flow
- signup.html     Account creation with optional phone, company and job title
- dashboard.html  Analytics dashboard with multiple charts
- documents.html Searchable document library + multi-file upload demo
- sharing.html    Collaborators, permissions and access requests
- audit.html      Filterable audit timeline + security charts
- profile.html    Editable profile information and logout

Shared assets:
- styles.css      Shared warm terracotta, sage, cream and muted gold theme
- app.js          Navigation, upload metadata, filters, charts, profile and demo auth

HOW TO RUN
1. Extract the ZIP archive.
2. Open the folder in VS Code.
3. Run index.html with the Live Server extension.
4. Create an account or sign in; use My Profile to edit profile details.
5. Use Documents > Upload document to select supported files.

SUPPORTED FILE TYPES
PDF, JPG, JPEG, PNG, GIF, WEBP, DOC, DOCX, XLS, XLSX, PPT, PPTX, TXT and CSV.
File names and metadata/description are stored in localStorage for this browser demo; file contents are not uploaded to a server.

SECURITY NOTE
This is a frontend-only demo. Demo account data, including password values, is stored in browser localStorage and is not secure authentication. Do not use real passwords or sensitive information. Production requires a backend with password hashing, sessions, access control and secure file storage.

Internet is needed for Google Fonts, Unsplash photos and Chart.js CDN.
